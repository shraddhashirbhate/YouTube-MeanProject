const Promise = require("bluebird");
const mysql = require("mysql");

const mod = require("./module");

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

const data = mod.DB_CONFIG;
console.log(data);

const readRecords = async () => {
    const Connection = mysql.createConnection(data);
    await Connection.connectAsync();

    let sql = "SELECT * FROM AddUser";
    let results = await Connection.queryAsync(sql);
    console.log(results);

    await Connection.endAsync();
    return results;

};

module.exports = {
    readRecords
};