const DB_Config = {
    host: "127.0.0.1",
    user: "root",
    password: "",
    database: "youtube"
};

module.exports = {
    DB_Config
};