const Promise = require("bluebird");
const mysql = require("mysql");

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

const DB_CONFIG = require("./module");
const data = DB_CONFIG.DB_Config;


let addRec = async (fullname, email,password) => {
    try {
        const con = mysql.createConnection(data);

        await con.connectAsync();

        let sql = "INSERT INTO AddUser VALUES (?,?,?)";
        let result = await con.queryAsync(sql, [fullname, email, password]);

        await con.endAsync();
        console.log(result.affectedRows);
        return result.affectedRows;
    } catch (err) {
        console.log("There is some error :", err.name);
    }

}

let addQueryJSON = async (user) => {
    try {
        const con = mysql.createConnection(data);

        await con.connectAsync();

        let sql = "INSERT INTO AddUser VALUES (?,?,?)";
        let result = await con.queryAsync(sql, [
            user.fullname,
            user.email,
            user.password
        ]);
        // console.log(result.affectedRows);
        console.log(user.email);
        console.log(user.fullname);
        console.log(user.password);

        await con.endAsync();



    } catch (err) {
        console.log("There is some error :", err.message, " and ", err.name);
    }

}




module.exports = {
    addRec,
    addQueryJSON
};