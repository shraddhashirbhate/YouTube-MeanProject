const Promise = require("bluebird");
const express = require("express");
const cors = require("cors");
const read = require("./ReadRec");
const add = require("./AddUser");

const app = express();
app.use(cors());

app.use(express.json());

app.get("/add", async (req, res) => {

    try {
        const input = req.query;
        await add.addQueryJSON(input);

        res.json({
            message: "Record added successfully!!"
        })
    } catch (err) {
        res.json({
            message: err.name
        })
    }
});


app.get("/read", async (req, res) => {
    try {
        const results = await read.readRecords();

        res.json(results);
        res.json({
            message: err
        })
    } catch (err) {
        const json = {
            message: "Failure"
        };
        res.json(json);
    }
});

app.post("/add", async (req, res) => {
    try {
        const input = req.body;
        await add.addQueryJSON(input);
        res.json({
            message: "record added successfully!!"
        })
    } catch (err) {
        node
        res.json({
            message: err.name
        });
    }
});



app.listen(8080);