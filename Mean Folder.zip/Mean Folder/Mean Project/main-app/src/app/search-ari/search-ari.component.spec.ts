import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchAriComponent } from './search-ari.component';

describe('SearchAriComponent', () => {
  let component: SearchAriComponent;
  let fixture: ComponentFixture<SearchAriComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchAriComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchAriComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
