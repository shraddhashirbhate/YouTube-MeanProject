import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { YTappComponent } from './ytapp.component';

describe('YTappComponent', () => {
  let component: YTappComponent;
  let fixture: ComponentFixture<YTappComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ YTappComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(YTappComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
