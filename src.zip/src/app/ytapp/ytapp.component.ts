import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ytapp',
  templateUrl: './ytapp.component.html',
  styleUrls: ['./ytapp.component.css']
})
export class YTappComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
