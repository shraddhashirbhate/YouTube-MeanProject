import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { FormBuilder, Validators } from '@angular/forms';
import { FormControl } from '@angular/forms';


@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {

  public uiInvalidCredential = false;
  public fbFormGroup = this.fb.group({
    FullName: ['', Validators.required],
    Email: ['', Validators.required],
    Password: ['', Validators.required],
  });
  constructor(
    private fb: FormBuilder,
    private router: Router,
    private http: HttpClient
  ) { }

  ngOnInit(): void {
  }

  gotoPage(page) {
    this.router.navigate([page]);
  }

  async readFormValue() {
    const data = this.fbFormGroup.value;
    //console.log(data.mobile.indexOf('@'))
    if (data.Email.indexOf('@') === 0 || (data.Email.indexOf('.') !== data.Email.length - 3 && data.Email.indexOf('.') !== data.Email.length - 4)) {
      alert("Please Enter Valid Email Id");
    }

    else if (data.password.length < 4 || data.password.length > 15) {
      alert("minimum length of Password should be 3")
    }
    else {

      // const url1 = 'http://127.0.0.0:8080/read';
      // const result: any = await this.http.post(url1, data).toPromise();
      // console.log(result);
      // if (!result.opr) {

      const url = 'http://127.0.0.1:8080/add';
      await this.http.post(url, data).toPromise();
      this.router.navigate(['LoginPage']);

      // }
      // else {
      //   alert("you are already registered");
      //   //this.uiInvalidCredential = true;
      // }

    }

  }


  // myFormGroup = new FormGroup({
  //   fullname: new FormControl('', [
  //       Validators.required,
  //       Validators.minLength(3),
  //       Validators.maxLength(20),

  //   ]),
  //   email: new FormControl('', [
  //     Validators.required,
  //       Validators.minLength(3),
  //       Validators.maxLength(20),
  //   ]),
  //   password: new FormControl('', [
  //     Validators.required,
  //       Validators.minLength(3),
  //       Validators.maxLength(20),
  //   ])
  // });

  // public NameControl1 = new FormControl('', [
  //   Validators.required,
  //   Validators.minLength(3),
  //   Validators.maxLength(20),
  // ]);

  // public NameControl2 = new FormControl('', [
  //   Validators.required,
  //   Validators.minLength(3),
  //   Validators.maxLength(20),
  //   Validators.pattern('[a-zA-Z0-9]')
  // ]);

  // public NameControl3 = new FormControl('', [
  //   Validators.required,
  //   Validators.minLength(3),
  //   Validators.maxLength(20),
  //   Validators.pattern('[a-zA-Z0-9]')
  // ])

  // async fetchData() {
  //   const userJson() {
  //     FullName: 'Harshada Kerkar',
  //       email: 'harshada@gmail.com',
  //         password: '123456'
  //   }
  // }

}
