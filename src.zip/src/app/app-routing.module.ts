import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { ProfileComponent } from './profile/profile.component';
import { NotificationComponent } from './notification/notification.component';
import { YTappComponent } from './ytapp/ytapp.component';
import { ChoreographyComponent } from './choreography/choreography.component';
import { HomeComponent } from './home/home.component';
import { ForgotPassComponent } from './forgot-pass/forgot-pass.component';
import { SearchAriComponent } from './search-ari/search-ari.component';
import { ErrorComponent } from './error/error.component';

const routes: Routes = [
  { path: "Login", component: LoginComponent },
  { path: "SignUp", component: SignUpComponent },
  { path: "Profile", component: ProfileComponent },
  { path: "Notification", component: NotificationComponent },
  { path: "YTapp", component: YTappComponent },
  { path: "Choreography", component: ChoreographyComponent },
  { path: "Home", component: HomeComponent },
  { path: "Error", component: ErrorComponent },
  { path: "Forgot", component: ForgotPassComponent },
  { path: "searchAri", component: SearchAriComponent },
  { path: "**", redirectTo: '/SignUp' }



];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
