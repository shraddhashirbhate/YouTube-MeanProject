import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { ProfileComponent } from './profile/profile.component';
import { NotificationComponent } from './notification/notification.component';
import { YTappComponent } from './ytapp/ytapp.component';
import { ChoreographyComponent } from './choreography/choreography.component';
import { HomeComponent } from './home/home.component';
import { ForgotPassComponent } from './forgot-pass/forgot-pass.component';
import { SearchAriComponent } from './search-ari/search-ari.component';
import { ErrorComponent } from './error/error.component';
import { Signup1Component } from './signup1/signup1.component';
import { Login1Component } from './login1/login1.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SignUpComponent,
    ProfileComponent,
    NotificationComponent,
    YTappComponent,
    ChoreographyComponent,
    HomeComponent,
    ForgotPassComponent,
    SearchAriComponent,
    ErrorComponent,
    Signup1Component,
    Login1Component,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
