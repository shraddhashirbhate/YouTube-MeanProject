import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-search-ari',
  templateUrl: './search-ari.component.html',
  styleUrls: ['./search-ari.component.css']
})
export class SearchAriComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit(): void {
  }

  gotoPage(page) {
    this.router.navigate([page]);
  }
}
